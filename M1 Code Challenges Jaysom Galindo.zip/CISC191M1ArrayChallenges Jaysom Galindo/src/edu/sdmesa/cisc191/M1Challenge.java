package edu.sdmesa.cisc191;

/**
 * Lead Author(s):
 * @author 
 * @author 
 * <<add additional lead authors here, with a full first and last name>>
 * 
 * Other contributors:
 * <<add additional contributors (mentors, tutors, friends) here, with contact information>>
 * 
 * References:
 * Morelli, R., & Walde, R. (2016). Java, Java, Java: Object-Oriented Problem Solving.
 * Retrieved from https://open.umn.edu/opentextbooks/textbooks/java-java-java-object-oriented-problem-solving
 * 
 * <<add more references here>>
 *  
 * Version/date: 
 * 
 * Responsibilities of class:
 * 
 */

 // See INSTRUCTIONS in TestM1Challenge

public class M1Challenge
{
	/**
	 * Purpose: add two numbers
	 * @param a one number
	 * @param b another number
	 * @return the sum of a and b
	 */
	public static int add(int a, int b)
	{
		return a + b;
	}
	
	/**
	 * Purpose: multiply two numbers
	 * @param a one number
	 * @param b another number
	 * @return the product of a and b
	 */
	public static int multiply(int a, int b)
	{
		// TODO: change this to make the tests pass
		return a * b;
	}
	
	/**
	 * Purpose: return the first element in the array given
	 * 
	 * @param array to search
	 * @return first element
	 */
	public static int getFirst(int[] array)
	{
		// TODO: change this method to make the tests pass
		return array[0];
	}
	
	/**
	 * Purpose: return the last element in the array given
	 * 
	 * @param array to search
	 * @return last element
	 */
	public static int getLast(int[] array)
	{
		// TODO: change this method to make the tests pass
		return array[-1];
	}
	
	/**
	 * Purpose: return the middle element in an array with an odd number of elements
	 * 
	 * @param array to search
	 * @return middle element
	 */
	public static int getMiddle(int[] array)
	{
		// TODO: change this method to make the tests pass
		int middleIndex = array.length / 2;
		return array[middleIndex];
	}
	
	// Use this template for the other methods
	/**
	 * Purpose:
	 * 
	 * @param array
	 * @return
	 */
//	public static ??? ???(???[] array)
//	{
//		return ???;
//	}
	/**
	 * Purpose: To find the maximum element in an array
	 * 
	 * @param array to search
	 * @return maximum element
	 */
	public static int max(int[] array)
	{
		//We assume index 0 is the largest integer as a starting point
		int largest = array[0];
		//this iterates through all integers from 0 to array length -1
		for(int i = 0; i < array.length; i++)
		{
			if (array[i] > largest)
			{
				largest = array[i];
			}
		}
		return largest;
	}

	/**
	 * Purpose: To find the smallest integer in an array
	 * 
	 * @param array to search
	 * @return minimum element
	 */
	public static int min(int[] array)
	{
		//We assume index 0 is the smallest integer as a starting point
		int smallest = array[0];
		//Iterates through array determines whether the current index it is looking at is the smallest integer
		for (int i = 0; i < array.length; i++)
		{
			if (array[i] < smallest)
			{
				smallest = array[i];
			}
		}
		return smallest;
	}

	/**
	 * Purpose: To find the sum integers in an array
	 * 
	 * @param array to use
	 * @return sum of integers
	 */
	public static int sum(int[] array)
	{
		//initialize variable total to be 0
		int total = 0;
		//iterates through array and adds each integer to the total
		for (int i = 0; i < array.length; i++)
		{
			total = total + array[i];
		}
		return total;
	}
	/**
	 * Purpose: To get the average of the of an array of integers
	 * 
	 * @param array to average
	 * @return average
	 */
	public static int average(int[] array)
	{
		//initializes total as 0
		int total = 0;
		//iterates through array to make a sum of integers, then divides by the number of integers to get the average of the integers
		for (int i = 0; i < array.length; i++)
		{
			total = total + array[i];
		}
		int average = total / array.length;
		return average;
	}
}
